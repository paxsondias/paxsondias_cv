import streamlit as st
import tensorflow as tf
from PIL import Image
import numpy as np

st.set_page_config(page_title="Skin Cancer Detector", layout="centered")

st.title("🩺 Skin Cancer Detection AI")
st.write("Upload a lesion image to analyze for Malignant or Benign characteristics.")

@st.cache_resource
def load_my_model():
    return tf.keras.models.load_model('C:/Users/Lezvita/Dropbox/PC/Downloads/skin cancer detection/New folder/models/skin_cancer_model.h5')

model = load_my_model()

uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded Image', use_column_width=True)
    
    # Preprocess
    img = image.resize((224, 224))
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    # Predict
    prediction = model.predict(img_array)[0][0]
    
    if prediction > 0.5:
        st.error(f"Prediction: MALIGNANT (Confidence: {prediction*100:.2f}%)")
    else:
        st.success(f"Prediction: BENIGN (Confidence: {(1-prediction)*100:.2f}%)")
    
    st.warning("Disclaimer: This is an AI tool for educational purposes. Please consult a doctor for medical diagnosis.")