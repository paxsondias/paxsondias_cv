import 'package:ecommrerce_catalog/features/products/screens/products_listing_screen.dart';
import 'package:ecommrerce_catalog/features/products/screens/sliver_bar.dart';
import 'package:ecommrerce_catalog/core/themes/dark_theme.dart';
import 'package:ecommrerce_catalog/core/themes/light_theme.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.light;
  void toggleTheme(){
    setState(() {
      _themeMode=_themeMode==ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: lightTheme,
      // ThemeData(
      //   colorScheme: .fromSeed(
      //     seedColor: Colors.yellow,
      //     brightness: Brightness.light,
          
      //   ),
        
      // ),
      darkTheme: darkTheme,
      // ThemeData(
      //   colorScheme: .fromSeed(
      //     seedColor: Colors.yellow,
      //     brightness: Brightness.dark,
          
      //   ),
      //   appBarTheme: AppBarTheme(backgroundColor: Colors.black,surfaceTintColor: Colors.amber,)
      // ),
      themeMode: _themeMode,
      home: ProductsListingScreen(
        themeMode: _themeMode,
        toggleTheme: toggleTheme
      ),
    );
  }
}
