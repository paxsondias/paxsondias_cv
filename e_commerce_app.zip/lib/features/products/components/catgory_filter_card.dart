import 'package:flutter/material.dart';

class CategoryFilterDialog extends StatelessWidget {
  final List<dynamic> categories;
  final Function(String) onSelect; // Sends the selected category back

  const CategoryFilterDialog({
    super.key,
    required this.categories,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min, // Takes only needed height
        children: [
          // Title
          const Text(
            'Choose a Category',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),

          // Category List
          Expanded(
            child: ListView.builder(
              shrinkWrap: true, // Prevents scroll overflow inside bottom sheet
              itemCount: categories.length,
              itemBuilder: (context, index) {
                final categoryName = categories[index].toString();
            
                return ListTile(
                  title: Text(categoryName),
                  onTap: () {
                    Navigator.pop(context); // 1. Close the sheet
                    onSelect(categoryName); // 2. Pass name to main screen
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}