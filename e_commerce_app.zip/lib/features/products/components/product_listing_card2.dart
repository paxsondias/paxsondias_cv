import 'package:ecommrerce_catalog/features/products/models/products_model.dart';
import 'package:ecommrerce_catalog/features/products/screens/product_detail_screen.dart';
import 'package:flutter/material.dart';

class ProductListingCard2 extends StatelessWidget {
  final Products prodducts;
  const ProductListingCard2({super.key, required this.prodducts});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                ProductDetailScreen(productId: prodducts.id!.toInt()),
          ),
        );
      },
      child: Container(
        height: 400,
        width: double.infinity,
        decoration: BoxDecoration(
          boxShadow: [BoxShadow(offset: Offset(2, 4),spreadRadius: 4, blurRadius: 10, color: Colors.grey)],
          borderRadius: BorderRadius.circular(20),
          color: Colors.white,
        ),
        child: Row(
          children: [
            Image.network(
              prodducts.thumbnail ?? prodducts.images![0],
              scale: 2,
            ),
            Center(
              child: Column(
                mainAxisAlignment: .center,
                children: [
                  Row(
                    children: [
                      Icon(Icons.star, color: Colors.amber),
                      Text(prodducts.rating.toString()),
                    ],
                  ),
                  Text(prodducts.title.toString()),
                  Text(
                    prodducts.brand.toString(),
                    style: TextStyle(color: Colors.grey.shade500),
                  ),
                  Text('\$${prodducts.price.toString()}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
