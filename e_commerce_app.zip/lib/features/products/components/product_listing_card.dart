import 'package:ecommrerce_catalog/features/products/models/products_model.dart';
import 'package:ecommrerce_catalog/features/products/screens/product_detail_screen.dart';
import 'package:flutter/material.dart';

class ProductListingCard extends StatelessWidget {
  final Products productss;

  const ProductListingCard({super.key, required this.productss});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                ProductDetailScreen(productId: productss.id!.toInt()),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(8),
        margin: const EdgeInsets.symmetric(horizontal: 3),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              spreadRadius: 2,
              blurRadius: 4,
              offset: const Offset(2, 4),
            ),
          ],
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Fixed height & fit to prevent overflow
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                productss.thumbnail ?? productss.images![0],
                height: 120,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const SizedBox(
                  height: 120,
                  child: Icon(Icons.broken_image, size: 50),
                ),
              ),
            ),
            const SizedBox(height: 8),

            // Rating and Category Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.star_rounded,color: Colors.amber,),
                    Text(
                      productss.rating.toString(),
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
                SizedBox(width: 5),
                
              ],
            ),
            
            const SizedBox(height: 6),
            

            // Title
            Text(
              productss.title.toString(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 4),
            Text(
              productss.brand.toString(),
              style: const TextStyle(fontSize: 12,color: Colors.grey),
            ),
            const SizedBox(height: 4),

            // Description
            Text('\$${
              productss.price.toString()}',
              style: const TextStyle(fontSize: 12,fontWeight: .w600),
            ),
            
          ],
        ),
      ),
    );
  }
}
