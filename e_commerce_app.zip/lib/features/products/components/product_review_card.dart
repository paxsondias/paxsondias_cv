import 'package:ecommrerce_catalog/features/products/models/products_model.dart';
import 'package:flutter/material.dart';

class ProductReviewCard extends StatelessWidget {
  final Reviews reeviews;

  const ProductReviewCard({super.key, required this.reeviews});

  @override
  Widget build(BuildContext context) {
    return 
    Container(margin: EdgeInsets.only(bottom: 10),padding: EdgeInsets.only(left: 10,top: 8),
      height: 40,
      width: double.infinity,
      decoration: BoxDecoration(color: Colors.white,boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              spreadRadius: 2,
              blurRadius: 4,
              offset: const Offset(2, 4),
            ),
          ],border: Border.all(width: 0.2),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(crossAxisAlignment: .start,children: [Text(reeviews.comment.toString(),)]),
    );
  }
}
