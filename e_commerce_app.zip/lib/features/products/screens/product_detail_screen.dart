import 'package:ecommrerce_catalog/core/api/api_service.dart';
import 'package:ecommrerce_catalog/features/products/components/product_review_card.dart';
import 'package:ecommrerce_catalog/features/products/models/products_model.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProductDetailScreen extends StatefulWidget {
  final int productId;

  const ProductDetailScreen({super.key, required this.productId});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  final ApiService _apiService = ApiService();
  List<Products> _productList = [];

  @override
  void initState() {
    super.initState();
    _fetchDetails();
  }

  void _fetchDetails() async {
    final data = await _apiService.fetchProductById(widget.productId);
    setState(() {
      _productList = [Products.fromJson(data)];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_productList.isEmpty ? '' : _productList[0].title!),
      ),
      body: _productList.isEmpty
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Image.network(
                      _productList[0].thumbnail!,
                      height: 200,
                    ),
                  ),
                  SizedBox(height: 16),
                  Text('ID: ${_productList[0].id}'),
                  SizedBox(height: 8),
                  Text(
                    _productList[0].title!,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '\$${_productList[0].price}',
                    style: GoogleFonts.lato(fontSize: 18, color: Colors.green),
                  ),
                  SizedBox(height: 8),
                  Text('Category: ${_productList[0].category!}',style: GoogleFonts.lato(fontWeight: .bold),),
                  SizedBox(height: 12),
                  Text('Discription:',style: GoogleFonts.lato(fontWeight: .bold),),
                  Text(_productList[0].description!,style: GoogleFonts.lato(),),
                  SizedBox(height: 12),
                  Text('Reviews:',style: GoogleFonts.lato(fontWeight: .bold),),
                  SizedBox(height: 12),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _productList[0].reviews?.length ?? 0,
                    itemBuilder: (context, index) {
                      final review = _productList[0].reviews![index];
                      return ProductReviewCard(reeviews: review);
                    },
                  ),
                ],
              ),
            ),
    );
  }
}
