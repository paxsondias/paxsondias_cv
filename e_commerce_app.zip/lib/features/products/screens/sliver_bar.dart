// import 'package:ecommrerce_catalog/core/api/api_service.dart';
// import 'package:ecommrerce_catalog/features/products/components/catgory_filter_card.dart';
// import 'package:ecommrerce_catalog/features/products/components/product_listing_card.dart';
// import 'package:ecommrerce_catalog/features/products/models/products_model.dart';
// import 'package:ecommrerce_catalog/features/products/screens/product_category_screen.dart';
// import 'package:flutter/material.dart';

// class ProductsListingScreen extends StatefulWidget {
//   final void Function() toggleTheme;
//   final ThemeMode themeMode;
//   const ProductsListingScreen({
//     super.key,
//     required this.toggleTheme,
//     required this.themeMode,
//   });

//   @override
//   State<ProductsListingScreen> createState() => _ProductsListingScreenState();
// }

// class _ProductsListingScreenState extends State<ProductsListingScreen> {
//   final ApiService apiService = ApiService();
//   final TextEditingController _searchController = TextEditingController();

//   List<Products> productlist = [];
//   List<dynamic> categoryList = [];
//   bool isGridView = true;

//   bool isLoading = true;
//   String errorMessage = '';
//   String searchText = '';

//   @override
//   void initState() {
//     super.initState();
//     loadData();
//   }

//   @override
//   void dispose() {
//     _searchController.dispose();
//     super.dispose();
//   }

//   void loadData() async {
//     try {
//       final fetchProduct = await apiService.fetchProduct();
//       final categories = await apiService.fetchCategories();

//       setState(() {
//         productlist = fetchProduct;
//         categoryList = categories;
//         isLoading = false;
//       });
//     } catch (e) {
//       setState(() {
//         errorMessage = e.toString();
//         isLoading = false;
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final searchResults = categoryList.where((category) {
//       return category.toString().toLowerCase().contains(
//         searchText.toLowerCase(),
//       );
//     }).toList();

//     return Scaffold(
//       body: isLoading
//           ? const Center(child: CircularProgressIndicator())
//           : errorMessage.isNotEmpty
//           ? Center(child: Text('Error: $errorMessage'))
//           : CustomScrollView(
//               physics: const BouncingScrollPhysics(),
//               slivers: [
//                 SliverAppBar(
//                   // backgroundColor: Colors.white,
//                   floating: false,
//                   pinned: true,
//                   expandedHeight:
//                       120, // Adjusted from 500 for better proportion
//                   title: TextField(
//                     controller: _searchController,
//                     onChanged: (value) {
//                       setState(() {
//                         searchText = value;
//                       });
//                     },
//                     decoration: const InputDecoration(
//                       hintText: 'Search categories',
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.all(Radius.circular(10)),
//                       ),
//                     ),
//                   ),

//                   actions: [
//                     IconButton(
//                       onPressed: widget.toggleTheme,
//                       icon: Icon(widget.themeMode == Icons.light ? Icons.dark_mode: Icons.light),
//                     ),
//                     IconButton(
//                       icon: Icon(isGridView ? Icons.list : Icons.grid_view),
//                       onPressed: () {
//                         setState(() {
//                           isGridView = !isGridView;
//                         });
//                       },
//                     ),
//                   ],
//                 ),
//                 if (searchText.isNotEmpty)
//                   SliverList(
//                     delegate: SliverChildBuilderDelegate((context, index) {
//                       final category = searchResults[index].toString();
//                       return ListTile(
//                         title: Text(category),
//                         onTap: () {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                               builder: (context) => CategoryProductsScreen(
//                                 categoryName: category,
//                               ),
//                             ),
//                           );
//                         },
//                       );
//                     }, childCount: searchResults.length),
//                   )
//                 else if (isGridView)
//                   SliverPadding(
//                     padding: const EdgeInsets.all(10),
//                     sliver: SliverGrid(
//                       gridDelegate:
//                           const SliverGridDelegateWithFixedCrossAxisCount(
//                             crossAxisCount: 2,
//                             crossAxisSpacing: 10,
//                             mainAxisSpacing: 10,
//                             mainAxisExtent: 240,
//                           ),
//                       delegate: SliverChildBuilderDelegate(
//                         (context, index) =>
//                             ProductListingCard(productss: productlist[index]),
//                         childCount: productlist.length,
//                       ),
//                     ),
//                   )
//                 else
//                   SliverPadding(
//                     padding: const EdgeInsets.all(10),
//                     sliver: SliverList(
//                       delegate: SliverChildBuilderDelegate(
//                         (context, index) => Padding(
//                           padding: const EdgeInsets.only(bottom: 10),
//                           child: ProductListingCard(
//                             productss: productlist[index],
//                           ),
//                         ),
//                         childCount: productlist.length,
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//       floatingActionButton: FloatingActionButton.extended(
//         onPressed: () {
//           // Show bottom sheet
//           showModalBottomSheet(
//             context: context,
//             builder: (context) {
//               return CategoryFilterDialog(
//                 categories: categoryList,
//                 onSelect: (selectedName) {
//                   // Navigate when a category is tapped
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) =>
//                           CategoryProductsScreen(categoryName: selectedName),
//                     ),
//                   );
//                 },
//               );
//             },
//           );
//         },
//         icon: const Icon(Icons.filter_list),
//         label: const Text('Filter'),
//       ),
//     );
//   }
// }
