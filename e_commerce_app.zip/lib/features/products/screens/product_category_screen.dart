import 'package:ecommrerce_catalog/core/api/api_service.dart';
import 'package:ecommrerce_catalog/features/products/components/catgory_filter_card.dart';
import 'package:ecommrerce_catalog/features/products/components/product_listing_card.dart';
import 'package:ecommrerce_catalog/features/products/models/products_model.dart';
import 'package:flutter/material.dart';

class CategoryProductsScreen extends StatefulWidget {
  final String categoryName;

  const CategoryProductsScreen({super.key, required this.categoryName});

  @override
  State<CategoryProductsScreen> createState() => _CategoryProductsScreenState();
}

class _CategoryProductsScreenState extends State<CategoryProductsScreen> {
  final ApiService _apiService = ApiService();
  List<Products> _products = [];
  List<dynamic> categoryList = [];
  bool _isLoading = true;
  String _errorMessage = '';
  bool _isGridView = true; // State to track current layout

  @override
  void initState() {
    super.initState();
    _loadCategoryProducts();
  }

  void _loadCategoryProducts() async {
    try {
      final items = await _apiService.fetchProductsByCategory(
        widget.categoryName,
      );
      final categories = await _apiService.fetchCategories();
      setState(() {
        categoryList = categories;
        _products = items;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.categoryName.toUpperCase(),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        actions: [
          // Toggle button with dynamic icon
          IconButton(
            icon: Icon(_isGridView ? Icons.view_list : Icons.grid_view),
            onPressed: () {
              setState(() {
                _isGridView = !_isGridView;
              });
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage.isNotEmpty
          ? Center(child: Text('Error: $_errorMessage'))
          : _products.isEmpty
          ? const Center(child: Text('No products found in this category.'))
          // Ternary operator switching between GridView and ListView
          : _isGridView
          ? GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                mainAxisExtent: 240,
              ),
              itemCount: _products.length,
              itemBuilder: (context, index) {
                return ProductListingCard(productss: _products[index]);
              },
            )
          : ListView.builder(
              padding: EdgeInsets.all(10),
              itemCount: _products.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: ProductListingCard(productss: _products[index]),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // Show bottom sheet
          showModalBottomSheet(
            context: context,
            builder: (context) {
              return CategoryFilterDialog(
                categories: categoryList,
                onSelect: (selectedName) {
                  // Navigate when a category is tapped
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CategoryProductsScreen(categoryName: selectedName),
                    ),
                  );
                },
              );
            },
          );
        },
        icon: const Icon(Icons.filter_list),
        label: const Text('Filter'),
      ),
    );
  }
}
