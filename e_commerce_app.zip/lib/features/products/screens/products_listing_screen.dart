import 'package:ecommrerce_catalog/core/api/api_service.dart';
import 'package:ecommrerce_catalog/features/products/components/catgory_filter_card.dart';
import 'package:ecommrerce_catalog/features/products/components/product_listing_card.dart';
import 'package:ecommrerce_catalog/features/products/components/product_listing_card2.dart';
import 'package:ecommrerce_catalog/features/products/models/products_model.dart';
import 'package:ecommrerce_catalog/features/products/screens/product_category_screen.dart';
import 'package:flutter/material.dart';

class ProductsListingScreen extends StatefulWidget {
  final void Function() toggleTheme;
  final ThemeMode themeMode;
  const ProductsListingScreen({
    super.key,
    required this.toggleTheme,
    required this.themeMode,
  });

  @override
  State<ProductsListingScreen> createState() => _ProductsListingScreenState();
}

class _ProductsListingScreenState extends State<ProductsListingScreen> {
  final ApiService apiService = ApiService();
  final TextEditingController _searchController = TextEditingController();

  List<Products> productlist = [];
  List<dynamic> categoryList = [];
  bool isGridView = true;

  bool isLoading = true;
  String errorMessage = '';
  String searchText = '';

  @override
  void initState() {
    super.initState();
    loadData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void loadData() async {
    try {
      final fetchProduct = await apiService.fetchProduct();
      final categories = await apiService.fetchCategories();

      setState(() {
        productlist = fetchProduct;
        categoryList = categories;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = e.toString();
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final searchResults = categoryList.where((category) {
      return category.toString().toLowerCase().contains(
        searchText.toLowerCase(),
      );
    }).toList();

    return Scaffold(
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage.isNotEmpty
          ? Center(child: Text('Error: $errorMessage'))
          : CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverAppBar(
                  // backgroundColor: Colors.white,
                  floating: false,
                  pinned: true,
                  expandedHeight:
                      120, // Adjusted from 500 for better proportion
                  title: TextField(
                    controller: _searchController,
                    onChanged: (value) {
                      setState(() {
                        searchText = value;
                      });
                    },
                    decoration: const InputDecoration(
                      hintText: 'Search categories',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                    ),
                  ),

                  actions: [
                    IconButton(
                      onPressed: widget.toggleTheme,
                      icon: Icon(widget.themeMode == Icons.light ? Icons.dark_mode: Icons.light),
                    ),
                    IconButton(
                      icon: Icon(isGridView ? Icons.list : Icons.grid_view),
                      onPressed: () {
                        setState(() {
                          isGridView = !isGridView;
                        });
                      },
                    ),
                  ],
                ),
                if (searchText.isNotEmpty)
                  SliverList(
                    delegate: SliverChildBuilderDelegate((context, index) {
                      final category = searchResults[index].toString();
                      return ListTile(
                        title: Text(category),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CategoryProductsScreen(
                                categoryName: category,
                              ),
                            ),
                          );
                        },
                      );
                    }, childCount: searchResults.length),
                  )
                else if (isGridView)
                  SliverPadding(
                    padding: const EdgeInsets.all(10),
                    sliver: SliverGrid(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 10,
                            mainAxisSpacing: 10,
                            mainAxisExtent: 240,
                          ),
                      delegate: SliverChildBuilderDelegate(
                        (context, index) =>
                            ProductListingCard(productss: productlist[index]),
                        childCount: productlist.length,
                      ),
                    ),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.all(10),
                    sliver: SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: ProductListingCard2(
                            prodducts: productlist[index],
                          ),
                        ),
                        childCount: productlist.length,
                      ),
                    ),
                  ),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // Show bottom sheet
          showModalBottomSheet(
            context: context,
            builder: (context) {
              return CategoryFilterDialog(
                categories: categoryList,
                onSelect: (selectedName) {
                  // Navigate when a category is tapped
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CategoryProductsScreen(categoryName: selectedName),
                    ),
                  );
                },
              );
            },
          );
        },
        icon: const Icon(Icons.filter_list),
        label: const Text('Filter'),
      ),
    );
  }
}


// import 'package:ecommrerce_catalog/products/api_service.dart';
// import 'package:ecommrerce_catalog/products/components/product_listing_card.dart';
// import 'package:ecommrerce_catalog/products/models/products_model.dart';
// import 'package:ecommrerce_catalog/products/screens/product_category_screen.dart';
// import 'package:flutter/material.dart';

// class ProductsListingScreen extends StatefulWidget {
//   const ProductsListingScreen({super.key});

//   @override
//   State<ProductsListingScreen> createState() => _ProductsListingScreenState();
// }

// class _ProductsListingScreenState extends State<ProductsListingScreen> {
//   final ApiService apiService = ApiService();
//   final TextEditingController _searchController = TextEditingController();

//   List<Products> productlist = [];
//   List<dynamic> categoryList = [];
//   String? selectedCategory;
//   bool isGridView = true;

//   bool isLoading = true;
//   String errorMessage = '';

//   // 1. Simple search text variable
//   String searchText = '';

//   @override
//   void initState() {
//     super.initState();
//     loadData();
//   }

//   @override
//   void dispose() {
//     _searchController.dispose();
//     super.dispose();
//   }

//   void loadData() async {
//     try {
//       final fetchProduct = await apiService.fetchProduct();
//       final categories = await apiService.fetchCategories();

//       setState(() {
//         productlist = fetchProduct;
//         categoryList = categories;
//         isLoading = false;
//       });
//     } catch (e) {
//       setState(() {
//         errorMessage = e.toString();
//         isLoading = false;
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     // 2. Simple list filtering: matches whatever is in categoryList
//     final searchResults = categoryList.where((category) {
//       return category
//           .toString()
//           .toLowerCase()
//           .contains(searchText.toLowerCase());
//     }).toList();

//     return Scaffold(
//       appBar: AppBar(
//         title: TextField(
//           controller: _searchController,
//           // 3. Whenever user types, update searchText and rebuild screen
//           onChanged: (value) {
//             setState(() {
//               searchText = value;
//             });
//           },
//           decoration: const InputDecoration(
//             hintText: 'Search categories',
//             border: InputBorder.none,
//           ),
//         ),
//         actions: [
//           Padding(
//             padding: const EdgeInsets.only(right: 10.0),
//             child: DropdownButtonHideUnderline(
//               child: DropdownButton<String>(
//                 value: selectedCategory,
//                 hint: const Text('Category'),
//                 // Dropdown is completely untouched and uses the original categoryList
//                 items: categoryList.map((cat) {
//                   return DropdownMenuItem<String>(
//                     value: cat.toString(),
//                     child: Text(cat.toString()),
//                   );
//                 }).toList(),
//                 onChanged: (value) {
//                   if (value != null) {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                         builder: (context) =>
//                             CategoryProductsScreen(categoryName: value),
//                       ),
//                     );
//                   }
//                 },
//               ),
//             ),
//           ),
//           IconButton(
//             icon: Icon(isGridView ? Icons.list : Icons.grid_view),
//             onPressed: () {
//               setState(() {
//                 isGridView = !isGridView;
//               });
//             },
//           ),
//         ],
//       ),
//       body: isLoading
//           ? const Center(child: CircularProgressIndicator())
//           : errorMessage.isNotEmpty
//               ? Center(child: Text('Error: $errorMessage'))
//               // 4. IF search is not empty -> show search results
//               : searchText.isNotEmpty
//                   ? ListView.builder(
//                       itemCount: searchResults.length,
//                       itemBuilder: (context, index) {
//                         final category = searchResults[index].toString();
//                         return ListTile(
//                           title: Text(category),
//                           onTap: () {
//                             Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                                 builder: (context) => CategoryProductsScreen(
//                                   categoryName: category,
//                                 ),
//                               ),
//                             );
//                           },
//                         );
//                       },
//                     )
//                   // 5. ELSE -> show original products (Grid or List)
//                   : isGridView
//                       ? GridView.builder(
//                           physics: const BouncingScrollPhysics(),
//                           gridDelegate:
//                               const SliverGridDelegateWithFixedCrossAxisCount(
//                             crossAxisCount: 2,
//                             crossAxisSpacing: 10,
//                             mainAxisSpacing: 10,
//                             mainAxisExtent: 240,
//                           ),
//                           itemCount: productlist.length,
//                           itemBuilder: (context, index) =>
//                               ProductListingCard(productss: productlist[index]),
//                         )
//                       : ListView.builder(
//                           itemCount: productlist.length,
//                           itemBuilder: (context, index) => Padding(
//                             padding: const EdgeInsets.only(bottom: 10),
//                             child: ProductListingCard(
//                                 productss: productlist[index]),
//                           ),
//                         ),
//     );
//   }
// }