
import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:ecommrerce_catalog/features/products/models/products_model.dart';

class ApiService {
  final Dio _dio = Dio();

  Future<List<Products>> fetchProduct() async {
  try {
    // 1. Correct API endpoint
    final response = await _dio.get('https://dummyjson.com/products');

    if (response.statusCode == 200) {
      // Option A: Use your ProductsResponse class (Recommended)
      final productsResponse = ProductsResponse.fromJson(response.data);
      return productsResponse.products ?? [];

      /* 
      // Option B: Manual extraction if you don't want to use ProductsResponse
      final Map<String, dynamic> responseData = response.data;
      final List<dynamic> rawData = responseData['products'] ?? []; // Key is 'products'
      
      return rawData.map((item) => Products.fromJson(item)).toList();
      */
    } else {
      throw Exception('Failed to load products');
    }
  } catch (e) {
    rethrow;
  }
}
// Add this method inside your existing ApiService class:

Future<Map<String, dynamic>> fetchProductById(int id) async {
  try {
    final response = await _dio.get('https://dummyjson.com/products/$id');
    
    if (response.statusCode == 200) {
      return response.data as Map<String, dynamic>;
    } else {
      throw Exception('Failed to load product: ${response.statusCode}');
    }
  } on DioException catch (e) {
    throw Exception(e.message ?? 'Dio request error');
  }
}

// Fetches list of categories (e.g. ['beauty', 'fragrances', 'furniture', ...])
Future<List<dynamic>> fetchCategories() async {
  try {
    final response = await _dio.get('https://dummyjson.com/products/category-list');
    
    if (response.statusCode == 200) {
      return response.data as List<dynamic>;
    } else {
      throw Exception('Failed to load categories: ${response.statusCode}');
    }
  } on DioException catch (e) {
    throw Exception(e.message ?? 'Dio network error');
  }
}

// Fetch products by category name
Future<List<Products>> fetchProductsByCategory(String category) async {
  try {
    log('message');
    final response = await _dio.get('https://dummyjson.com/products/category/$category');
    
    if (response.statusCode == 200) {
      final data = response.data['products'] as List;
      return data.map((json) => Products.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load category products: ${response.statusCode}');
    }
  } on DioException catch (e) {
    throw Exception(e.message ?? 'Dio network error');
  }
}

}