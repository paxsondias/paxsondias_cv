import 'dart:developer';
import 'package:firebase_login/core/firestore_db.dart';
import 'package:firebase_login/features/add%20_task_screen.dart';
import 'package:firebase_login/features/list_screen.dart';
import 'package:firebase_login/models/model.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final DatabaseService _databaseService = DatabaseService();

    return Scaffold(
      backgroundColor: Colors.teal.shade200,
      appBar: AppBar(
        actionsPadding: EdgeInsets.only(right: 20),
        backgroundColor: const Color.fromARGB(255, 10, 107, 97),
        title: Text('ToDo App', style: TextStyle(color: Colors.white)),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AddTaskScreen()),
              );
            },
            icon: Icon(Icons.add, size: 40, color: Colors.white),
          ),
        ],
      ),
      body: StreamBuilder(
        stream: _databaseService.getTodos(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            log('Stream error: ${snapshot.error}');
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          List todos = snapshot.data?.docs ?? [];
          log(todos.toString());
          if (todos.isEmpty) {
            return const Center(child: Text("Add a todo!"));
          }
          return Expanded(
            child: ListView.builder(
              itemCount: todos.length,
              itemBuilder: (context, index) {
                TodoModel todoitem = todos[index].data();
                String todoId = todos[index].id;
                log(todoitem.toString());
                return ListComponent(todo: todoitem, id: todoId, databaseService: _databaseService,);
              },//updation step3: transfer the id and databaseservice data from homescreen to list screen
            ),
          );
        },
      ),
    );
  }
}
