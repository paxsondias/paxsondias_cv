import 'dart:developer';

// import 'package:counter/listing_task/models/todos_model.dart';
import 'package:firebase_login/core/firestore_db.dart';
import 'package:firebase_login/models/model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
// import 'package:intl/intl.dart';

class ListComponent extends StatelessWidget {
  final TodoModel todo;
  final String id;
  const ListComponent({super.key, required this.todo, required this.id, required DatabaseService databaseService,});

  @override
  Widget build(BuildContext context) {
    final DateTime time= todo.date;
    final newtime=DateFormat().add_MMMMEEEEd().format(time);
    return GestureDetector(onLongPress: () => DatabaseService().deletetodo(id),
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        padding: EdgeInsets.all(10),
      
        decoration: BoxDecoration(
          shape: .rectangle,
          color: (todo.priority == 'high')
              ? Colors.red.shade300
              : todo.priority == 'medium'
              ? Colors.teal
              : Color.fromARGB(255, 73, 164, 239),
          boxShadow: [
            BoxShadow(
              blurStyle: BlurStyle.solid,
              blurRadius: 2,
              offset: Offset(2, 4),
              color: Colors.black,
              spreadRadius: 2,
            ),
          ],
          borderRadius: .circular(10),
        ),
        child: Column(
          crossAxisAlignment: .start,
          children: [
            Row(
              mainAxisAlignment: .spaceBetween,
              children: [
                Flexible(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(width: 2),
                    ),
                    child: Text(
                      todo.priority.toString().toUpperCase(),
                      style: TextStyle(
                        fontSize: 12,
                        color: todo.priority == 'high'
                            ? const Color.fromARGB(255, 180, 22, 11)
                            : todo.priority == 'medium'
                            ? const Color.fromARGB(255, 10, 107, 97)
                            : const Color.fromARGB(255, 32, 86, 129),
                      ),
                    ),
                  ),
                ),
                Checkbox(
                  value: todo.isDone,
                  onChanged: (value) {
                    TodoModel updateTodo = todo.copyWith(isDone: !todo.isDone);
                    DatabaseService().updateTodo(id, updateTodo);//updation step4: link the model and function to update the ui 
                    // if (value = true) {
                    //   Checkbox(value: true, onChanged: (value) {});
                    // } else {
                    //   Checkbox(value: false, onChanged: (value) {});
                    // }
                  },
                ),
              ],
            ),
      
            SizedBox(height: 10),
            Text(
              todo.task.toString(),
              style: TextStyle(fontSize: 20, fontWeight: .w700),
            ),
            Text('Description: ${todo.description.toString()}'),
      
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: .spaceBetween,
              children: [
                SizedBox(width: 120,
                  child: Text(
                    '#${todo.hashtags.join(', #')}',
                    style: TextStyle(fontWeight: .bold),
                  ),
                ),
                SizedBox(height: 10),
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 2),
                      borderRadius: BorderRadius.circular(30),
                      color: const Color.fromARGB(255, 30, 124, 90),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    child: Text(
                      todo.taskType.toString(),
                      style: TextStyle(fontSize: 15),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: .end,
              children: [Text(newtime.toString(), style: TextStyle())],
            ),
          ],
        ),
      ),
    );
  }
}
