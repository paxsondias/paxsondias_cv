// import 'package:counter/listing_task/core/json_data.dart';
// import 'package:draggable_home/draggable_home.dart';
// import 'package:draggable_home/draggable_home.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:draggable_home/draggable_home.dart';
import 'package:firebase_login/core/firestore_db.dart';
import 'package:firebase_login/models/model.dart';
import 'package:flutter/material.dart';

class AddTaskScreen extends StatefulWidget {
  const AddTaskScreen({super.key});

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final TextEditingController _titleController = TextEditingController();//Taskadding step2: create controllers to store text
  final TextEditingController _discriptionController = TextEditingController();
  final TextEditingController _hashController = TextEditingController();

  final List<String> priorityList = ['high', 'Medium', 'Low'];
  final List<String> categoryList = [
    'work',
    'design',
    'developmont',
    'education',
  ];

  // 2. Variable to hold the selected value
  String? selectedcategory;
  String? selectedPriority;
  DateTime selecteddate = DateTime.now();

  @override
  void dispose() {
    _titleController.dispose();
    _discriptionController.dispose();
    _hashController.dispose();
    super.dispose();
  }

  // void _submitData() {
  //   // 2 & 3. Extract and package values into a Map
  //   final formData = {
  //     'Task Title': _titleController.text,
  //     'discription': _discriptionController.text,
  //   };

  Future<void> _openDatePicker() async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selecteddate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (pickedDate != null && pickedDate != selecteddate) {
      setState(() {
        selecteddate = pickedDate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // final todoItem = JsonData.todoData;

    return DraggableHome(
      backgroundColor: Colors.teal.shade200,
      appBarColor: Color.fromARGB(255, 10, 107, 97),
      title: Text('ToDo App', style: TextStyle(color: Colors.white)),
      headerWidget: Container(
        height: 200,
        width: 100,
        color: Color.fromARGB(255, 10, 107, 97),
        child: Image.network(
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrLse9iPRCKQOxeACr65nrBA50Y6Ka89ChCUUrftyseA&s=10',
        ),
      ),
      body: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 20),
          margin: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black,
                spreadRadius: 2,
                offset: Offset(2, 4),
              ),
            ],
          ),
          height: 490,
          width: double.infinity,
          child: Column(
            spacing: 18,
            children: [
              SizedBox(height: 10),
              TextField(
                controller: _titleController,
                decoration: InputDecoration(
                  hintText: 'Task Title',
                  border: OutlineInputBorder(
                    borderSide: BorderSide(width: 2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              Flexible(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                      child: Row(
                        children: [
                          DropdownButton<String>(
                            hint: Text('Priority Level'),
                            value: selectedPriority,

                            // Map the custom list to DropdownMenuItems
                            items: priorityList.map((String item) {
                              return DropdownMenuItem<String>(
                                value: item,
                                child: Text(item),
                              );
                            }).toList(),

                            // Update the UI when an item is tapped
                            onChanged: (String? newValue) {
                              setState(() {
                                selectedPriority = newValue;
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                    Flexible(
                      child: Row(
                        children: [
                          DropdownButton<String>(
                            hint: Text('Category'),
                            value: selectedcategory,

                            // Map the custom list to DropdownMenuItems
                            items: categoryList.map((String item) {
                              return DropdownMenuItem<String>(
                                value: item,
                                child: Text(item),
                              );
                            }).toList(),

                            // Update the UI when an item is tapped
                            onChanged: (String? newValue) {
                              setState(() {
                                selectedcategory = newValue;
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              TextField(
                controller: _discriptionController,
                decoration: InputDecoration(
                  hintText: 'Discription',
                  border: OutlineInputBorder(
                    borderSide: BorderSide(width: 2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              TextField(
                controller: _hashController,
                decoration: InputDecoration(
                  hintText: '#HashTag',
                  border: OutlineInputBorder(
                    borderSide: BorderSide(width: 2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              TextField(
                enabled: false,

                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    onPressed: _openDatePicker,
                    icon: Icon(Icons.calendar_month),
                  ),
                  hintText: selecteddate.toString(),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(width: 2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: _openDatePicker,
                child: Text(
                  'Select date',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ElevatedButton(//Taskaddition step3: create a button on prssend it sends the values to db through model structure
                onPressed: () {
                  TodoModel todo = TodoModel(
                    date: selecteddate,
                    description: _discriptionController.text,
                    hashtags: _hashController.text
                      .split(',')
                      .map((hashtag) => hashtag.trim())
                      .where((hashtag) => hashtag.isNotEmpty)
                      .toList(),
                    isDone: false,
                    taskType: selectedcategory ?? '',
                    priority: selectedPriority ?? '',
                    task: _titleController.text,
                  );
                  DatabaseService().addTodo(todo);//call the add todo function from databaseservice class
                  return dispose();
                },
                child: Text(
                  'Done',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
