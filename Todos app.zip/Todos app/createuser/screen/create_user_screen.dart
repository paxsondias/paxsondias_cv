import 'dart:developer';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_login/login/screen/login_screen.dart';
import 'package:firebase_login/login/screen/next_page.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:heroicons/heroicons.dart';

class CreateUserScreen extends StatelessWidget {
  const CreateUserScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController createusercontroller = TextEditingController();
    final TextEditingController createpasswordcontroller = TextEditingController();
    
        
    return Scaffold(
      body: SingleChildScrollView(
        child: Expanded(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: .center,
                children: [
                  Text('English (India)'),
                  HeroIcon(HeroIcons.chevronDown),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  spacing: 10,
                  children: [
                    TextField(

                      controller: createusercontroller,
                      strutStyle: const StrutStyle(height: 0.5),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 2,
                            color: Colors.grey.shade400,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: 2, color: Colors.black),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        hintText: 'Username, email address or mobile number',
                      ),
                    ),
                    TextField(
                      controller: createpasswordcontroller,
                      strutStyle: const StrutStyle(height: 0.5),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 2,
                            color: Colors.grey.shade400,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 2,
                            color: Colors.black,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        hintText: 'Password',
                      ),
                    ),
                    SizedBox(
                      height: 40,
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: WidgetStatePropertyAll(
                            Colors.blue.shade700,
                          ),
                          foregroundColor: WidgetStatePropertyAll(Colors.white),
                        ),
                        onPressed: () async {
                          log('test');
                          String message = '';
                            if (createusercontroller.text.trim().isNotEmpty &&
                              createpasswordcontroller.text.isNotEmpty) {
                            try {
                              await FirebaseAuth.instance.createUserWithEmailAndPassword(
                                email: createusercontroller.text.trim(),
                                password: createpasswordcontroller.text,
                              );
                              Future.delayed(const Duration(seconds: 3), () {
                                Navigator.of(context, rootNavigator: true).push(
                                  MaterialPageRoute(
                                    builder: (_) => const LoginScreen(),
                                  ),
                                );
                              });
                            } on FirebaseAuthException catch (e) {
                              if (e.code == 'weak-password') {
                                message = 'The password provided is too weak.';
                              } else if (e.code == 'email-already-in-use') {
                                message =
                                    'An account already exists with that email.';
                              }
                              Fluttertoast.showToast(
                                msg: message,
                                toastLength: Toast.LENGTH_LONG,
                                gravity: ToastGravity.SNACKBAR,
                                backgroundColor: Colors.black54,
                                textColor: Colors.white,
                                fontSize: 14.0,
                              );
                            } catch (e) {
                              Fluttertoast.showToast(
                                msg: "Failed: $e",
                                toastLength: Toast.LENGTH_LONG,
                                gravity: ToastGravity.SNACKBAR,
                                backgroundColor: Colors.black54,
                                textColor: Colors.white,
                                fontSize: 14.0,
                              );
                            }
                          }
                        },
                        child: Text('Create user'),
                      ),
                    ),
                    
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
