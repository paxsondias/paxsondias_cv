// // import 'dart:nativewrappers/_internal/vm/lib/developer.dart';

import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_login/models/model.dart';

const String todo_collection_ref =
    "todos"; //"todos" is the reference to the firestore db

class DatabaseService {
  final _firestore = FirebaseFirestore
      .instance; //create a variable _firestore which connects the firestore to the app
  late final CollectionReference
  _todosRef; // linking to my collections in the db
  DatabaseService() {
    log('db service fn excuted');
    _todosRef = _firestore
        .collection(todo_collection_ref)
        .withConverter<TodoModel>(
          fromFirestore: (snapshots, _) =>
              TodoModel.fromJson(snapshots.data()!),
          toFirestore: (value, _) => value.toJson(),
        );
        log(_todosRef.toString());
  } //this part helps in the back and forth flow of the data between db and the app through the model

  Stream<QuerySnapshot> getTodos() {
    log('getTodos fn executed');
    return _todosRef.snapshots();
  }//this is the function which is called to get the data from the db

  void addTodo(TodoModel value) async{
    _todosRef.add(value);
  }//Taskaddition step1://this is the function which is called when you want to send the data to the db

  void updateTodo(String id, TodoModel value){
    _todosRef.doc(id).update(value.toJson());
  } //updation step2: this function is used to update the values in the db

  void deletetodo(String id){
    _todosRef.doc(id).delete();
  }
}




// import 'dart:developer';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_login/models/model.dart';

// const String todo_collection_ref = "todos";

// class DatabaseService {
//   final _firestore = FirebaseFirestore.instance;
  
//   // 1. Specify <TodoModel> so Dart knows the exact document type
//   late final CollectionReference<TodoModel> _todosRef;

//   DatabaseService() {
//     log('db service fn excuted');
//     log('Connected Firebase Project ID: ${_firestore.app.options.projectId}'); // <-- ADD THIS LINE
//     log('Database ID: ${_firestore.databaseId}'); // <-- ADD THIS LINE
//     _todosRef = _firestore
//         .collection(todo_collection_ref)
//         .withConverter<TodoModel>(
//           fromFirestore: (snapshots, _) =>
//               TodoModel.fromJson(snapshots.data()!),
//           toFirestore: (value, _) => value.toJson(),
//         );
//     log(_todosRef.toString());
//   }

//   // 2. Return Stream<QuerySnapshot<TodoModel>>
//   Stream<QuerySnapshot<TodoModel>> getTodos() {
//     log('getTodos fn executed');
//     return _todosRef.snapshots();
//   }

//   // 3. Use Future<void>, await the call, and log any errors
//   Future<void> addTodo(TodoModel value) async {
//     try {
//       await _todosRef.add(value);
//       log('Todo added successfully');
//     } catch (e) {
//       log('Error adding todo: $e');
//     }
//   }
// }