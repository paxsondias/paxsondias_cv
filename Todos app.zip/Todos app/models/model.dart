import 'package:cloud_firestore/cloud_firestore.dart';

class TodoModel {
  DateTime date;
  String description;
  List<String> hashtags;
  bool isDone;
  String taskType;
  String priority;
  String task;

  TodoModel({
    required this.date,
    required this.description,
    required this.hashtags,
    required this.isDone,
    required this.taskType,
    required this.priority,
    required this.task,
  });

  TodoModel.fromJson(Map<String, dynamic> json)
    : date =
          DateTime.tryParse(json['Date']?.toString() ?? '') ?? DateTime.now(),
      description = json['Discription']?.toString() ?? '',
      hashtags = List<String>.from(json['Hashtags'] ?? const []),
      isDone = json['IsDone'] as bool? ?? false,
      taskType = json['TaskType']?.toString() ?? '',
      priority = json['priority']?.toString() ?? '',
      task = json['task']?.toString() ?? '';

  TodoModel copyWith({
    //updation step1: create updation model method
    final Timestamp? date,
    final bool? isDone,
    final String? description,
    final List<String>? hashtags,
    final String? taskType,
    final String? priority,
    final String? task,
  }) {
    return TodoModel(
      date:
          date?.toDate() ??
          this.date, //?? is the null-coalescing operator. It means: "If the value on the left is null, use the value on the right."
      description: description ?? this.description, //? means the value can be null
      hashtags: hashtags ?? this.hashtags,
      isDone: isDone ?? this.isDone,
      taskType: taskType ?? this.taskType,
      priority: priority ?? this.priority,
      task: task ?? this.task,
    );
  }

  Map<String, dynamic> toJson() {
    //updation
    return {
      'Date': date.toIso8601String(),
      'Discription': description,
      'Hashtags': hashtags,
      'IsDone': isDone,
      'TaskType': taskType,
      'priority': priority,
      'task': task,
    };
  }
}
