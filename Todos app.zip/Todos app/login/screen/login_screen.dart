import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_login/createuser/screen/create_user_screen.dart';
import 'package:firebase_login/features/home_screen.dart';
import 'package:firebase_login/login/screen/next_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:heroicons/heroicons.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController usercontroller = TextEditingController();
    final TextEditingController passwordController = TextEditingController();
    return Scaffold(
      appBar: AppBar(leading: Icon(Icons.arrow_back)),
      body: SingleChildScrollView(
        child: Expanded(
          child: Column(
            spacing: 110,
            children: [
              Row(
                mainAxisAlignment: .center,
                children: [
                  Text('English (India)'),
                  HeroIcon(HeroIcons.chevronDown),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  spacing: 10,
                  children: [
                    TextField(
                      controller: usercontroller,
                      strutStyle: const StrutStyle(height: 0.5),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 2,
                            color: Colors.grey.shade400,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: 2, color: Colors.black),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        hintText: 'Username, email address or mobile number',
                      ),
                    ),
                    TextField(
                      controller: passwordController,
                      strutStyle: const StrutStyle(height: 0.5),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 2,
                            color: Colors.grey.shade400,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 2,
                            color: Colors.black,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        hintText: 'Password',
                      ),
                    ),
                    SizedBox(
                      height: 40,
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: WidgetStatePropertyAll(
                            Colors.blue.shade700,
                          ),
                          foregroundColor: WidgetStatePropertyAll(Colors.white),
                        ),
                        onPressed: () async {
                          String message = '';
                          if (usercontroller.text.trim().isNotEmpty &&
                              passwordController.text.isNotEmpty) {
                            try {
                              await FirebaseAuth.instance
                                  .signInWithEmailAndPassword(
                                    email: usercontroller.text.trim(),
                                    password: passwordController.text,
                                  );
                              Future.delayed(const Duration(seconds: 3), () {
                                print('success');
                                Navigator.of(context, rootNavigator: true).push(
                                  MaterialPageRoute(
                                    builder: (_) => const HomeScreen(),
                                  ),
                                );
                              });
                            } on FirebaseAuthException catch (e) {
                              if (e.code == 'INVALID_LOGIN_CREDENTIALS') {
                                message = 'Invalid login credentials.';
                              } else {
                                message = e.code;
                              }
                              Fluttertoast.showToast(
                                msg: message,
                                toastLength: Toast.LENGTH_LONG,
                                gravity: ToastGravity.SNACKBAR,
                                backgroundColor: Colors.black54,
                                textColor: Colors.white,
                                fontSize: 14.0,
                              );
                            }
                          }
                        },
                        child: Text('Log in'),
                      ),
                    ),
                    Text('Forgotten password?'),
                  ],
                ),
              ),
              Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: GestureDetector(onTap: () => Navigator.of(context, rootNavigator: true).push(
                                  MaterialPageRoute(
                                    builder: (_) => const CreateUserScreen(),
                                  ),
                                ),
                      child: TextField(
                        strutStyle: StrutStyle(height: 0.5),
                        decoration: InputDecoration(
                          floatingLabelAlignment: FloatingLabelAlignment.center,
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(width: 2, color: Colors.blue),
                          ),
                          label: Center(child: Text('Create new account')),
                        ),
                      ),
                    ),
                  ),

                  Row(
                    mainAxisAlignment: .center,
                    children: [
                      Icon(CupertinoIcons.infinite, color: Colors.blue),
                      Text('Meta', style: TextStyle(fontWeight: .bold)),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
