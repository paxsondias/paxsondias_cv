import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import math

# Set layout configurations
st.set_page_config(page_title="Samsung Global Sales Dashboard", layout="wide")

# Title and introduction
st.title("📊 Samsung Global Sales Analytics Dashboard")
st.markdown("An interactive application exploring chronological trends, customer demographics, behavioral distributions, and product returns.")

# --- 1. LOAD DATA ---
@st.cache_data
def load_data():
    df = pd.read_csv('samsung_global_sales_dataset.csv')
    df['year_quarter'] = df['year'].astype(str) + " " + df['quarter']
    # Ensure sequential timeline sorting
    df = df.sort_values(['year', 'quarter', 'month'])
    return df

try:
    df = load_data()
except FileNotFoundError:
    st.error("Could not find 'samsung_global_sales_dataset.csv'. Please make sure the file is in the same directory.")
    st.stop()

# --- 2. SIDEBAR FILTERS ---
st.sidebar.header("Filter Analytics")

# Region Filter
all_regions = ["All Regions"] + sorted(df['region'].unique().tolist())
selected_region = st.sidebar.selectbox("Select Geographic Region", all_regions)

# Year Filter
all_years = ["All Years"] + sorted(df['year'].unique().tolist())
selected_year = st.sidebar.selectbox("Select Fiscal Year", all_years)

# Filter Dataframe based on selections
filtered_df = df.copy()
if selected_region != "All Regions":
    filtered_df = filtered_df[filtered_df['region'] == selected_region]
if selected_year != "All Years":
    filtered_df = filtered_df[filtered_df['year'] == int(selected_year)]


# --- 3. HIGH-LEVEL KPI METRICS ---
total_revenue = filtered_df['revenue_usd'].sum()
total_units = filtered_df['units_sold'].sum()
avg_rating = filtered_df['customer_rating'].mean()

col1, col2, col3 = st.columns(3)
with col1:
    st.metric(label="Total Revenue (USD)", value=f"${total_revenue:,.2f}")
with col2:
    st.metric(label="Total Units Sold", value=f"{total_units:,}")
with col3:
    st.metric(label="Average Customer Rating", value=f"{avg_rating:.2f} ★")

st.markdown("---")

# --- 4. TABS FOR DIFFERENT DASHBOARD SECTIONS ---
tab1, tab2, tab3 = st.tabs(["📉 Chronological Timelines", "🎯 Price & Behavioral Analysis", "👥 Demographics Deep-Dive"])

# ==============================================================================
# TAB 1: CHRONOLOGICAL TIMELINES (Product Quarterly Sales)
# ==============================================================================
with tab1:
    st.header("Chronological Product Performance")
    
    # Dropdown to pick category rather than flooding the page with 11 charts
    selected_category = st.selectbox(
        "Choose a Product Line to View Quarterly Progression:",
        sorted(filtered_df['category'].unique())
    )
    
    cat_timeline_df = filtered_df[filtered_df['category'] == selected_category]
    quarterly_sales = cat_timeline_df.groupby('year_quarter')['units_sold'].sum().reset_index()
    quarterly_sales = quarterly_sales.sort_values('year_quarter')
    
    if not quarterly_sales.empty:
        fig, ax = plt.subplots(figsize=(12, 5))
        sns.barplot(data=quarterly_sales, x='year_quarter', y='units_sold', palette='Blues_d', ax=ax)
        ax.set_title(f'Quarterly Units Sold Timeline: {selected_category}', fontsize=14, fontweight='bold')
        ax.set_xlabel('Timeline Bracket', fontsize=12)
        ax.set_ylabel('Total Units Sold', fontsize=12)
        plt.xticks(rotation=45)
        st.pyplot(fig)
    else:
        st.warning("No timeline data found for the current filtered scope.")

# ==============================================================================
# TAB 2: PRICE & BEHAVIORAL ANALYSIS (Scatter, Histogram, Correlations)
# ==============================================================================
with tab2:
    st.header("Pricing Distributions & Behavioral Metrics")
    
    col_price1, col_price2 = st.columns(2)
    
    with col_price1:
        st.subheader("Price Points vs. Gross Transaction Volume")
        # Weighted Histogram showing units sold vs discounted price usd
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.histplot(data=filtered_df, x='discounted_price_usd', weights='units_sold', bins=30, kde=True, color='purple', ax=ax)
        ax.set_title('Histogram: Volume of Units Sold by Discounted Price', fontsize=12, fontweight='bold')
        ax.set_xlabel('Discounted Price (USD)')
        ax.set_ylabel('Total Units Sold')
        st.pyplot(fig)
        
    with col_price2:
        st.subheader("Discounted Pricing Impact on Revenue generation")
        # Scatter plot discount price usd vs revenue usd
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.scatterplot(data=filtered_df, x='discounted_price_usd', y='revenue_usd', alpha=0.6, color='coral', ax=ax)
        ax.set_title('Discounted Price (USD) vs. Gross Revenue (USD)', fontsize=12, fontweight='bold')
        ax.set_xlabel('Discounted Price (USD)')
        ax.set_ylabel('Revenue (USD)')
        st.pyplot(fig)

    st.markdown("---")
    st.subheader("Feature Interaction Matrix")
    
    # Calculate numerical correlations
    numeric_cols = filtered_df.select_dtypes(include=['number'])
    if not numeric_cols.empty:
        corr_matrix = numeric_cols.corr()
        fig, ax = plt.subplots(figsize=(12, 8))
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5, ax=ax, vmin=-1, vmax=1)
        ax.set_title('Correlation Heatmap Matrix of Numerical Features', fontsize=14, fontweight='bold')
        st.pyplot(fig)

# ==============================================================================
# TAB 3: DEMOGRAPHICS DEEP-DIVE (OS Returns, Payment Methods, Custom Segments)
# ==============================================================================
with tab3:
    st.header("Customer Profiles & Retention Metrics")
    
    col_demo1, col_demo2 = st.columns(2)
    
    with col_demo1:
        st.subheader("Product Rejection & Prior Ecosystem Share")
        # Filter for returns and map via pie chart
        returned_df = filtered_df[filtered_df['return_status'] == 'Returned'].copy()
        returned_df['previous_device_os'] = returned_df['previous_device_os'].fillna('Unknown')
        os_return_counts = returned_df['previous_device_os'].value_counts()
        
        if not os_return_counts.empty:
            fig, ax = plt.subplots(figsize=(8, 8))
            ax.pie(
                os_return_counts, labels=os_return_counts.index, autopct='%1.1f%%', startangle=140, 
                colors=['#5c768d', '#e6a15c', '#4da6a9', '#db6b63', '#a381b8', '#89b65c'],
                wedgeprops={'edgecolor': 'white', 'linewidth': 2}
            )
            ax.set_title('Distribution of Returned Items by Prior Mobile OS', fontsize=12, fontweight='bold')
            st.pyplot(fig)
        else:
            st.info("No returns recorded within this filtered segment criteria.")
            
    with col_demo2:
        st.subheader("Transaction Profiles Across Lifespans")
        # Top 3 payment method vs age group
        top_payment_methods = filtered_df['payment_method'].value_counts().nlargest(3).index.tolist()
        pay_age_df = filtered_df[filtered_df['payment_method'].isin(top_payment_methods)]
        
        if not pay_age_df.empty:
            grouped_pay = pay_age_df.groupby(['customer_age_group', 'payment_method']).size().reset_index(name='count')
            grouped_pay = grouped_pay.sort_values('customer_age_group')
            
            fig, ax = plt.subplots(figsize=(10, 8))
            sns.barplot(data=grouped_pay, x='customer_age_group', y='count', hue='payment_method', palette='Set2', ax=ax)
            ax.set_title('Top 3 Global Payment Methods Chosen per Age Bracket', fontsize=12, fontweight='bold')
            ax.set_xlabel('Age Group')
            ax.set_ylabel('Transaction Counter')
            st.pyplot(fig)
        else:
            st.warning("Insufficient metrics available to generate payment charts.")

    st.markdown("---")
    st.subheader("Top Performing Targets Per Demographic Cohort")
    
    col_grid1, col_grid2 = st.columns(2)
    
    with col_grid1:
        st.markdown("**Top 3 Customer Segments per Age Group**")
        age_segment_sales = filtered_df.groupby(['customer_age_group', 'customer_segment'])['units_sold'].sum().reset_index()
        top_3_segments = age_segment_sales.groupby('customer_age_group').apply(lambda x: x.nlargest(3, 'units_sold')).reset_index(drop=True)
        
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.barplot(data=top_3_segments, x='customer_age_group', y='units_sold', hue='customer_segment', palette='magma', ax=ax)
        ax.set_xlabel('Age Group')
        ax.set_ylabel('Total Units Sold')
        st.pyplot(fig)

    with col_grid2:
        st.markdown("**Top 3 Sales Channels per Age Group**")
        channel_sales = filtered_df.groupby(['customer_age_group', 'sales_channel'])['units_sold'].sum().reset_index()
        top_3_channels = channel_sales.groupby('customer_age_group').apply(lambda x: x.nlargest(3, 'units_sold')).reset_index(drop=True)
        
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.barplot(data=top_3_channels, x='customer_age_group', y='units_sold', hue='sales_channel', palette='viridis', ax=ax)
        ax.set_xlabel('Age Group')
        ax.set_ylabel('Total Units Sold')
        st.pyplot(fig)