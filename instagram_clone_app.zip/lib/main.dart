import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:instagram_app/core/routes.dart';
import 'package:instagram_app/features/homepage/screens/post_screen.dart';
import 'package:instagram_app/features/profile.dart/screen/profile_screen.dart';
import 'package:instagram_app/features/reel/screen/reels_screen.dart';
import 'package:instagram_app/features/search/screen/search_screen.dart';
import 'package:instagram_app/features/settings/screens/settings_screens.dart';

void main() {
  runApp(const MyApp());
}

// GoRouter configuration

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routerConfig: router,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
    );
  }
}
