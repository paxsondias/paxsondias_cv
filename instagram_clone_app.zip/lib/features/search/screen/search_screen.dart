import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:go_router/go_router.dart';

class BackGroundTile extends StatelessWidget {
  final Color backgroundColor;
  final IconData icondata;

  const BackGroundTile({
    super.key,
    required this.backgroundColor,
    required this.icondata,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: backgroundColor,
      child: Icon(icondata, color: Colors.white),
    );
  }
}

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    List<StaggeredGridTile> cardTile = [
      StaggeredGridTile.count(
        crossAxisCellCount: 1,
        mainAxisCellCount: 2,
        child: BackGroundTile(
          backgroundColor: Colors.red,
          icondata: Icons.home,
        ),
      ),
      StaggeredGridTile.count(
        crossAxisCellCount: 1,
        mainAxisCellCount: 1,
        child: BackGroundTile(
          backgroundColor: Colors.orange,
          icondata: Icons.ac_unit,
        ),
      ),
      StaggeredGridTile.count(
        crossAxisCellCount: 1,
        mainAxisCellCount: 2,
        child: BackGroundTile(
          backgroundColor: Colors.pink,
          icondata: Icons.landscape,
        ),
      ),
      StaggeredGridTile.count(
        crossAxisCellCount: 1,
        mainAxisCellCount: 1,
        child: BackGroundTile(
          backgroundColor: Colors.green,
          icondata: Icons.portrait,
        ),
      ),
      StaggeredGridTile.count(
        crossAxisCellCount: 2,
        mainAxisCellCount: 2,
        child: BackGroundTile(
          backgroundColor: Colors.deepPurpleAccent,
          icondata: Icons.music_note,
        ),
      ),
      StaggeredGridTile.count(
        crossAxisCellCount: 5,
        mainAxisCellCount: 2,
        child: BackGroundTile(
          backgroundColor: Colors.deepPurpleAccent,
          icondata: Icons.music_note,
        ),
      ),
      StaggeredGridTile.count(
        crossAxisCellCount: 2,
        mainAxisCellCount: 2,
        child: BackGroundTile(
          backgroundColor: Colors.blue,
          icondata: Icons.access_alarms,
        ),
      ),
      StaggeredGridTile.count(
        crossAxisCellCount: 2,
        mainAxisCellCount: 2,
        child: BackGroundTile(
          backgroundColor: Colors.indigo,
          icondata: Icons.satellite_outlined,
        ),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => context.go('/'),
          icon: Icon(Icons.arrow_back),
        ),
        title: TextField(
          strutStyle: StrutStyle(height: 0.5),
          decoration: InputDecoration(
            fillColor: Colors.grey.shade200,
            filled: true,
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(20),
            ),
            prefixIcon: Icon(Icons.search),
            hintText: 'Search',
          ),
        ),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Padding(
              //   padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
              //   child: TextField(
              //     strutStyle: StrutStyle(height: 0.5),
              //     decoration: InputDecoration(
              //       fillColor: Colors.grey.shade200,
              //       filled: true,
              //       border: OutlineInputBorder(
              //         borderSide: BorderSide.none,
              //         borderRadius: BorderRadius.circular(20),
              //       ),
              //       prefixIcon: Icon(Icons.search),
              //       hintText: 'Search',
              //     ),
              //   ),
              // ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: StaggeredGrid.count(
                  crossAxisCount: 2,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: cardTile,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

// class SearchScreen extends StatelessWidget {
//   final Color backgroundColor;
//   final IconData icondata;

//   const SearchScreen({
//     super.key,
//     required this.backgroundColor,
//     required this.icondata,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       color: backgroundColor,
//       child: Icon(icondata, color: Colors.white),
//     );
//   }
// }

// //List of Cards with size
//   List<StaggeredGridTile> cardTile = [
//     StaggeredGridTile.count(
//       crossAxisCellCount: 1,
//       mainAxisCellCount: 2,
//       child: SearchScreen(backgroundColor: Colors.red, icondata: Icons.home),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 1,
//       mainAxisCellCount: 1,
//       child: SearchScreen(
//         backgroundColor: Colors.orange,
//         icondata: Icons.ac_unit,
//       ),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 1,
//       mainAxisCellCount: 2,
//       child: SearchScreen(
//         backgroundColor: Colors.pink,
//         icondata: Icons.landscape,
//       ),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 1,
//       mainAxisCellCount: 1,
//       child: SearchScreen(
//         backgroundColor: Colors.green,
//         icondata: Icons.portrait,
//       ),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 4,
//       mainAxisCellCount: 2,
//       child: SearchScreen(
//         backgroundColor: Colors.deepPurpleAccent,
//         icondata: Icons.music_note,
//       ),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 4,
//       mainAxisCellCount: 2,
//       child: SearchScreen(
//         backgroundColor: Colors.blue,
//         icondata: Icons.access_alarms,
//       ),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 4,
//       mainAxisCellCount: 2,
//       child: SearchScreen(
//         backgroundColor: Colors.indigo,
//         icondata: Icons.satellite_outlined,
//       ),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 4,
//       mainAxisCellCount: 2,
//       child: SearchScreen(
//         backgroundColor: Colors.deepPurpleAccent,
//         icondata: Icons.music_note,
//       ),
//     ),
//     StaggeredGridTile.count(
//       crossAxisCellCount: 4,
//       mainAxisCellCount: 2,
//       child: SearchScreen(
//         backgroundColor: Colors.deepPurpleAccent,
//         icondata: Icons.music_note,
//       ),
//     ),
//   ];

// @override
// Widget build(BuildContext context) {
//   return Scaffold(
//     body: SingleChildScrollView(
//       child: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 10),
//             child: TextField(
//               strutStyle: const StrutStyle(height: 0.5),
//               decoration: InputDecoration(
//                 fillColor: Colors.grey,
//                 filled: true,
//                 border: OutlineInputBorder(
//                   borderSide: BorderSide.none,
//                   borderRadius: BorderRadius.circular(20),
//                 ),
//                 prefixIcon: const Icon(Icons.search),
//                 hintText: 'Search',
//               ),
//             ),
//           ),
//           StaggeredGrid.count(
//             crossAxisCount: 2,
//             mainAxisSpacing: 4,
//             crossAxisSpacing: 4,
//             children: cardTile,
//           ),
//         ],
//       ),
//     ),

//     // MasonryGridView.count(
//     //   shrinkWrap: true,
//     //   physics: NeverScrollableScrollPhysics(),
//     //   crossAxisCount: 3,
//     //   mainAxisSpacing: 8,
//     //   crossAxisSpacing: 8,
//     //   itemCount: 20,
//     //   itemBuilder: (context, index) {
//     //     // Giving items calculated heights to show the masonry effect
//     //     double height = (index % 5 + 1) * 50.0;

//     //     return Container(
//     //       height: height,
//     //       color: Colors.blueAccent,
//     //       child: Center(child: Text('Item $index')),
//     //     );
//     //   },
//     // ),

//     // GridView.builder(
//     //   itemCount: 40,
//     //   shrinkWrap: true,
//     //   physics: const NeverScrollableScrollPhysics(),
//     //   gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//     //     crossAxisCount: 3,
//     //     crossAxisSpacing: 2,
//     //     mainAxisSpacing: 2,
//     //   ),
//     //   itemBuilder: (context, index) {
//     //     return Container(color: Colors.amber);
//     //   },
//     // ),
//     // GridView.builder(
//     //   itemCount: 40,
//     //   shrinkWrap: true,
//     //   physics: NeverScrollableScrollPhysics(),
//     //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//     //     crossAxisCount: 3,
//     //     crossAxisSpacing: 2,
//     //     mainAxisSpacing: 2,
//     //   ),
//     //   itemBuilder: (context, index) {
//     //     return Container(height: 80, width: 15, color: Colors.amber);
//     //   },
//     // ),
//   );
// }
