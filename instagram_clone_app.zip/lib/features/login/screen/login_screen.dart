import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:heroicons/heroicons.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: Icon(Icons.arrow_back)),
      body: SingleChildScrollView(
        child: Expanded(
          child: Column(
            spacing: 110,
            children: [
              Row(
                mainAxisAlignment: .center,
                children: [
                  Text('English (India)'),
                  HeroIcon(HeroIcons.chevronDown),
                ],
              ),
              Image(
                height: 80,
                image: AssetImage('lib/core/assets/instagram-logo-vector.png'),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  spacing: 10,
                  children: [
                    TextField(
                      strutStyle: const StrutStyle(height: 0.5),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 2,
                            color: Colors.grey.shade400,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: 2, color: Colors.black),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        hintText: 'Username, email address or mobile number',
                      ),
                    ),
                    TextField(
                      strutStyle: const StrutStyle(height: 0.5),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 2,
                            color: Colors.grey.shade400,
                          ), 
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 2,
                            color: Colors.black,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        hintText: 'Password',
                      ),
                    ),
                    SizedBox(
                      height: 40,
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: WidgetStatePropertyAll(
                            Colors.blue.shade700,
                          ),
                          foregroundColor: WidgetStatePropertyAll(Colors.white),
                        ),
                        onPressed: () => context.go('/'),
                        child: Text('Log in'),
                      ),
                    ),
                    Text('Forgotten password?'),
                  ],
                ),
              ),
              Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: TextField(
                      strutStyle: StrutStyle(height: 0.5),
                      decoration: InputDecoration(
                        floatingLabelAlignment: FloatingLabelAlignment.center,
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide(width: 2, color: Colors.blue),
                        ),
                        label: Center(child: Text('Create new account')),
                      ),
                    ),
                  ),

                  Row(
                    mainAxisAlignment: .center,
                    children: [
                      Icon(CupertinoIcons.infinite, color: Colors.blue),
                      Text('Meta', style: TextStyle(fontWeight: .bold)),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
