import 'package:flutter/material.dart';
import 'package:instagram_app/models/post_model.dart';

class ChatListWidget extends StatelessWidget {
  const ChatListWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      margin: EdgeInsets.symmetric(vertical: 4),
      height: 60,
      width: double.infinity,
      child: Row(
        children: [
          Container(
            height: 70,
            width: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.amber,
            ),
          ),
          SizedBox(width: 20),
          Column(mainAxisAlignment: .center,
            crossAxisAlignment: .start,
            children: [
              Text('Text', style: TextStyle(fontWeight: .bold)),
              Text('This is a long text', style: TextStyle(fontWeight: .bold)),
            ],
          ),
        ],
      ),
    );
  }
}
