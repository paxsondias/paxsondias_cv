import 'package:flutter/material.dart';
import 'package:instagram_app/models/post_model.dart';

class NoteComponent extends StatelessWidget {
  final Posts? pposts;
  const NoteComponent({super.key, this.pposts});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          children: [
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              height: 80,
              width: 80,
              decoration: BoxDecoration(
                color: Colors.amber,
                shape: BoxShape.circle,
              ),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              alignment: .center,
              padding: EdgeInsets.symmetric(horizontal: 5),
              height: 40,
              width: 60,
              child: Text('notesdvsfvbggdbg',style: TextStyle(fontSize: 12),overflow: .ellipsis,maxLines: 2,),
            ),
          ],
        ),
        SizedBox(
          width: 80,
          child: Text(
            'UserName',
            style: TextStyle(),
            overflow: .ellipsis,
            maxLines: 1,
          ),
        ),
      ],
    );
  }
}
