import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: HeroIcon(HeroIcons.arrowLeft),
        actionsPadding: EdgeInsets.only(right: 10),
        title: Text('Username', style: TextStyle(fontWeight: .bold)),
        actions: [
          HeroIcon(HeroIcons.userGroup),
          SizedBox(width: 10),
          HeroIcon(HeroIcons.phone),
          SizedBox(width: 10),
          HeroIcon(HeroIcons.videoCamera),
        ],
      ),
      bottomNavigationBar: Container(padding: EdgeInsets.symmetric(horizontal: 10),
        height: 100,
        width: double.infinity,
        child: Row(
          children: [
            Expanded(
              child: TextField(
                decoration: InputDecoration(fillColor: Colors.grey.shade400,filled: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  prefixIcon: HeroIcon(HeroIcons.camera),
                  hintText: 'Message...',
                  suffixIcon: Row(
                    spacing: 10,
                    mainAxisAlignment: .end,
                    mainAxisSize: .min,
                    children: [
                      Icon(Icons.mic),
                      Icon(Icons.photo),
                      Icon(Icons.emoji_emotions_outlined),
                      Icon(Icons.add_circle_outline_outlined),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
