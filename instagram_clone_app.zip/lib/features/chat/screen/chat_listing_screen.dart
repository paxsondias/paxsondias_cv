import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';
import 'package:instagram_app/features/chat/widget/chat_list_widget.dart';
import 'package:instagram_app/features/chat/widget/note_component.dart';
import 'package:instagram_app/models/post_model.dart';

class ChatListingScreen extends StatelessWidget {
  const ChatListingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actionsPadding: const EdgeInsets.only(right: 20),
        title: Center(
          child: Row(
            spacing: 6,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                'Diaspaxson',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              HeroIcon(HeroIcons.chevronDown, size: 20),
            ],
          ),
        ),
        actions: [HeroIcon(HeroIcons.pencilSquare)],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search or ask Meta AI',
                prefixIcon: HeroIcon(HeroIcons.magnifyingGlass),
                filled: true,
                fillColor: Colors.grey.shade200,
                border: OutlineInputBorder(
                  borderSide: BorderSide.none,
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
          ),
          SizedBox(height: 20,),
          SizedBox(
            height: 150,
            child: ListView.builder(
              padding: EdgeInsets.symmetric(horizontal: 10),
              scrollDirection: Axis.horizontal,
              itemCount: 10,
              itemBuilder: (context, index) => NoteComponent(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisAlignment: .spaceBetween,
              children: [
                Row(
                  children: [
                    Text(
                      'Message',
                      style: TextStyle(fontWeight: .bold, fontSize: 17),
                    ),
                    HeroIcon(HeroIcons.bell, size: 17),
                  ],
                ),
                Text(
                  'Requests',
                  style: TextStyle(
                    fontWeight: .bold,
                    fontSize: 17,
                    color: Colors.indigo,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: 10,
              itemBuilder: (context, index) {
                return ChatListWidget();
              },
            ),
          ),
        ],
      ),
    );
  }
}
