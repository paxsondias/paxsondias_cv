import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:heroicons/heroicons.dart';

class SettingsScreens extends StatelessWidget {
  const SettingsScreens({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => context.go('/profile_screen'),
          icon: Icon(Icons.arrow_back),
        ),
        title: Text('Settings and activity'),
      ),
      body: Column(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: [
                      TextField(
                        strutStyle: StrutStyle(height: 0.5),
                        decoration: InputDecoration(
                          fillColor: Colors.grey,
                          filled: true,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: .none,
                          ),
                          prefixIcon: Icon(Icons.search),
                          hintText: 'Search',
                        ),
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Text('Your account'),
                          Row(
                            children: [
                              Icon(CupertinoIcons.infinite),
                              Text('Meta'),
                            ],
                          ),
                        ],
                      ),
                      Row(
                        spacing: 20,
                        children: [
                          // HeroIcon(HeroIcons.)
                          Icon(Icons.person_outline_rounded),
                          Column(
                            crossAxisAlignment: .start,
                            children: [
                              Text(
                                'Accounts Center',
                                style: TextStyle(fontWeight: .bold),
                              ),
                              SizedBox(
                                width: 270,
                                child: Text(
                                  'Password, security, personal details, connected experiences, ad preferences',
                                  maxLines: 2,
                                ),
                              ),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                    ],
                  ),
                ),
                Divider(thickness: 5),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    spacing: 20,
                    crossAxisAlignment: .start,
                    children: [
                      Text('How you use Instagram'),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.bookmark_border_outlined),
                              Text('Saved'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [Icon(Icons.more_time), Text('Archive')],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.data_thresholding_outlined),
                              Text('Your activity'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.notifications_outlined),
                              Text('Notifications'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.access_time),
                              Text('Time management'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.tablet_mac),
                              Text('Instagram for tablets'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                    ],
                  ),
                ),
                Divider(thickness: 5),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    spacing: 20,
                    crossAxisAlignment: .start,
                    children: [
                      Text('How you use Instagram'),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.bookmark_border_outlined),
                              Text('Saved'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [Icon(Icons.more_time), Text('Archive')],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.data_thresholding_outlined),
                              Text('Your activity'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.notifications_outlined),
                              Text('Notifications'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.access_time),
                              Text('Time management'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: .spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.tablet_mac),
                              Text('Instagram for tablets'),
                            ],
                          ),
                          Icon(Icons.arrow_forward_ios_rounded),
                        ],
                      ),
                    ],
                  ),
                ),
                Divider(thickness: 5),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
