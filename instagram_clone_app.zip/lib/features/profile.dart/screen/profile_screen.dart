import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:heroicons/heroicons.dart';
import 'package:instagram_app/features/search/screen/search_screen.dart';
import 'package:instagram_app/features/settings/screens/settings_screens.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          leading: Padding(
            padding: const EdgeInsets.only(left: 2),
            child: Row(
              children: [
                GestureDetector(onTap: () => context.go('/'),child: Icon(Icons.arrow_back),),
                Icon(Icons.add, size: 30),
              ],
            ),
          ),
          title: Row(
            mainAxisAlignment: .center,
            spacing: 10,
            children: [
              HeroIcon(HeroIcons.lockClosed),
              // Icon(Icons.lock_outline,size: 15,),
              Text('diaspaxson'),
              HeroIcon(HeroIcons.chevronDown),
              // Icon(Icons.arrow_drop_down),
            ],
          ),
          actions: [
            Row(
              spacing: 8,
              children: [
                HeroIcon(HeroIcons.atSymbol),
                IconButton(
                  onPressed: () {
                    context.goNamed('Settings');
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //     builder: (context) => const SettingsScreens(),
                    //   ),
                    // );
                  },
                  icon: HeroIcon(HeroIcons.bars3),
                ),
              ],
            ),
          ],
          actionsPadding: EdgeInsets.only(right: 20),
        ),
        body: Padding(
          padding: const EdgeInsetsGeometry.only(left: 10),
          child: Column(
            spacing: 10,
            crossAxisAlignment: .start,
            children: [
              Row(
                children: [
                  Stack(
                    children: [
                      Container(
                        alignment: .bottomRight,
                        margin: EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 10,
                        ),
                        height: 80,
                        width: 80,
                        decoration: BoxDecoration(
                          color: Colors.amber,
                          shape: BoxShape.circle,
                        ),
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            shape: .circle,

                            border: Border.all(color: Colors.white, width: 2),
                            color: Colors.black,
                          ),
                          child: Icon(Icons.add, color: Colors.white, size: 15),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                        ),
                        alignment: .center,
                        padding: EdgeInsets.symmetric(horizontal: 5),
                        height: 40,
                        width: 60,
                        child: Text(
                          textAlign: .center,
                          "Today's vide... ",
                          style: TextStyle(fontSize: 12),
                          overflow: .ellipsis,
                          maxLines: 2,
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: .start,
                    children: [
                      Text('Paxson Dias', style: TextStyle(fontStyle: .italic)),
                      Row(
                        spacing: 50,
                        children: [
                          Column(children: [Text('3'), Text('posts')]),
                          Column(children: [Text('534'), Text('Followers')]),
                          Column(children: [Text('427'), Text('Following')]),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                children: [
                  Text('Goa'),
                  Icon(Icons.push_pin_rounded, size: 15, color: Colors.red),
                ],
              ),
              Container(
                padding: EdgeInsets.only(left: 5),
                width: 85,
                height: 20,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey, width: 0.5),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  spacing: 3,
                  children: [
                    Icon(Icons.add, size: 10, color: Colors.grey),
                    Text(
                      'Add banners',
                      style: TextStyle(fontSize: 10, color: Colors.grey),
                    ),
                  ],
                ),
              ),
              Row(
                spacing: 5,
                children: [
                  Container(
                    width: 160,
                    height: 30,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey.shade200,
                    ),
                    alignment: .center,
                    child: Text('Edit proile'),
                  ),
                  Container(
                    width: 160,
                    height: 30,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey.shade200,
                    ),
                    alignment: .center,
                    child: Text('Share proile'),
                  ),
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey.shade200,
                    ),
                    alignment: .center,
                    child: Icon(Icons.person_add_outlined),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                      shape: .circle,
                      border: Border.all(color: Colors.black),
                    ),
                    child: Icon(Icons.add),
                  ),
                  Text('New'),
                ],
              ),
              TabBar(
                tabs: [
                  Tab(icon: Icon(Icons.grid_on_outlined)),
                  Tab(icon: Icon(Icons.video_library_outlined)),
                  Tab(icon: Icon(Icons.loop)),
                  Tab(icon: Icon(Icons.person_pin_outlined)),
                ],
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: TabBarView(
                    children: [
                      Center(
                        child: GridView.builder(
                          itemCount: 3,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                crossAxisSpacing: 2,
                                mainAxisSpacing: 8,
                              ),
                          itemBuilder: (context, index) {
                            return Container(
                              height: 80,
                              width: 30,
                              decoration: BoxDecoration(color: Colors.black),
                            );
                          },
                        ),
                      ),
                      Center(child: Text("View reels")),
                      Center(child: Text("View ReShare")),
                      Center(child: Text("View Tags")),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
