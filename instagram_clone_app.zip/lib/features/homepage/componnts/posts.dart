import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';
import 'package:instagram_app/models/post_model.dart';

class Postsblock extends StatelessWidget {
  final Posts usersposts;
  const Postsblock({super.key, required this.usersposts});

  @override
  Widget build(BuildContext context) {
    bool isliked = true;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          spacing: 10,
          children: [
            Container(
              margin: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: AssetImage('lib/core/assets/images.jpg'),
                ),
              ),
              height: 30,
              width: 30,
            ),
            Column(
              children: [
                Text(
                  'UserId ${usersposts.userId.toString()}',
                  style: TextStyle(fontWeight: .bold),
                ),
              ],
            ),
          ],
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          height: 400,
          width: double.infinity,
          color: Colors.grey,
          child: Center(child: Text(usersposts.body.toString())),
        ),
        SizedBox(height: 5,),
        Row(
          mainAxisAlignment: .spaceBetween,
          children: [
            Row(
              spacing: 10,
              children: [
                Row(
                  children: [
                    (isliked = true)
                        ? Icon(Icons.favorite)
                        : Icon(Icons.favorite_border),

                    Text(usersposts.reactions!.likes.toString()),
                  ],
                ),
                Row(
                  children: [
                    HeroIcon(HeroIcons.chatBubbleOvalLeft),
                    Text(usersposts.reactions!.dislikes.toString()),
                  ],
                ),
                
                HeroIcon(HeroIcons.arrowPath),
                HeroIcon(HeroIcons.paperAirplane),
              ],
            ),
            Row(children: [HeroIcon(HeroIcons.bookmark)]),
          ],
        ),
        SizedBox(height: 10),
        Row(
          spacing: 10,
          children: [
            Text(
              'UserId ${usersposts.userId.toString()}',
              style: TextStyle(fontWeight: .bold),
            ),
            Expanded(
              child: Text(
                usersposts.title.toString(),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
