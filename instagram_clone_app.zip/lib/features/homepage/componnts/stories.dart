import 'package:flutter/material.dart';
import 'package:instagram_app/models/post_model.dart';

class Stories extends StatelessWidget {
  final Posts posts;
  const Stories({super.key, required this.posts});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
      child: Column(
        children: [
          // Circular Avatar for Story
          const CircleAvatar(
            radius: 35, // Proper size for a story
            backgroundImage: NetworkImage(
              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSICmPX7HVrXVG2gS_IWLY_caJf42RHkS3GgaBlU_cUAQ&s=10',
            ),
          ),
          const SizedBox(height: 4),
          // Username under the story
          Text(
            'User ${posts.userId}',
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}