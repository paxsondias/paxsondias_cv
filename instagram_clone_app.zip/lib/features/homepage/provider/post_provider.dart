// import 'package:flutter/material.dart';
// import 'package:instagram_app/core/api_service.dart';

// class PostProvider extends ChangeNotifier{
//   final ApiService _apiservice = Apiservice();
//   bool isLoad=true;
//   List<Posts> _
// }