import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:instagram_app/core/post_data.dart';
import 'package:instagram_app/features/homepage/componnts/posts.dart';
import 'package:instagram_app/features/homepage/componnts/stories.dart';
import 'package:instagram_app/features/profile.dart/screen/profile_screen.dart';
import 'package:instagram_app/features/reel/screen/reels_screen.dart';
import 'package:instagram_app/features/search/screen/search_screen.dart';
import 'package:instagram_app/models/post_model.dart';


class PostScreen extends StatefulWidget {
  const PostScreen({super.key});

  @override
  State<PostScreen> createState() => _PostScreenState();
}

class _PostScreenState extends State<PostScreen> {
  @override
  Widget build(BuildContext context) {
    
    final postsItem = PostData.posts;
    

    return Scaffold(
      backgroundColor: Colors.white,

      // 1. INSTAGRAM APP BAR
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0, // Removes the drop shadow
        leading: Icon(Icons.add, size: 30),
        title: Center(
          child: const Text(
            'Instagram',
            style: TextStyle(
              color: Colors.black,
              fontSize: 28,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite_border, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),

      // 2. UNIFIED SCROLLING BODY
      body: ListView.builder(
        // Add 1 to the item count to make room for the Stories row at the very top
        itemCount: postsItem.length + 1,
        itemBuilder: (context, index) {
          // Index 0 is always the Stories horizontal list
          if (index == 0) {
            return Column(
              children: [
                SizedBox(
                  height: 110,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: postsItem.length,
                    itemBuilder: (context, storyIndex) {
                      final storylist = postsItem[storyIndex];
                      return Stories(posts: Posts.fromJson(storylist));
                    },
                  ),
                ),
                // Thin grey line separating stories from posts
                Divider(height: 1, color: Colors.grey.shade300),
              ],
            );
          }

          // Indexes 1 and above are the vertical posts.
          // We subtract 1 from the index so we fetch the correct data from the array.
          final postlist = postsItem[index - 1];
          return Postsblock(usersposts: Posts.fromJson(postlist));
        },
      ),

      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 5.0,
        clipBehavior: Clip.antiAlias,
        child: SizedBox(
          height: kBottomNavigationBarHeight,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(icon: const Icon(Icons.home), onPressed: () {
                
              }),
              IconButton(
                icon: const Icon(Icons.video_collection_rounded),
                onPressed: () => context.go('/reels_screen'),
              ),
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () => context.go('/search_screen'),
              ),
              IconButton(
                icon: const Icon(Icons.account_circle_outlined),
                onPressed: () => context.go('/profile_screen'),
              ),
            ],
          ),
        ),
      ),

      // 3. INSTAGRAM BOTTOM NAVIGATION BAR
      // bottomNavigationBar: BottomNavigationBar(
      //   type: BottomNavigationBarType.fixed,
      //   backgroundColor: Colors.white,
      //   showSelectedLabels: false,
      //   showUnselectedLabels: false,
      //   iconSize: 28,
      //   currentIndex: 0,
      //   onTap: (value) {
      //     BottomNavigationBarItem(
      //       icon: IconButton(
      //         icon: Icon(Icons.home_filled, color: Colors.black),
      //         onPressed: () {
      //           Navigator.of(context).push(
      //             MaterialPageRoute(
      //               builder: (context) => ReelsScreen(),
      //             ),
      //           );
      //         },
      //       ),
      //       label: 'Home',
      //     );
      //   },

      //   items: const [

      //     BottomNavigationBarItem(
      //       icon: Icon(Icons.home_filled, color: Colors.black),
      //       label: 'Home',
      //     ),
      //     BottomNavigationBarItem(
      //       icon: Icon(Icons.play_arrow, color: Colors.black),
      //       label: 'Reel',
      //     ),
      //     BottomNavigationBarItem(
      //       icon: Icon(Icons.share, color: Colors.black),
      //       label: 'Share',
      //     ),
      //     BottomNavigationBarItem(
      //       icon: Icon(Icons.search, color: Colors.black), // Reels icon
      //       label: 'Search',
      //     ),
      //     // BottomNavigationBarItem(icon: CircleAvatar(child: Image(image: AssetImage('lib/core/assets/images.jpg')),))
      //     // BottomNavigationBarItem(icon: Icon())
      //   ],
      // ),
    );
  }
}
