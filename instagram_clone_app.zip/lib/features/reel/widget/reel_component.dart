import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';
import 'package:instagram_app/models/post_model.dart';

class ReelComponent extends StatelessWidget {
  const ReelComponent({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(bottom: 10),
          height: 770,
          width: double.infinity,
          color: Colors.amber,
        ),
        Positioned(
          left: 16.0,
          bottom: 16.0,
          child: Column(
            crossAxisAlignment: .start,
            children: [
              Row(
                crossAxisAlignment: .center,
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      shape: .circle,
                    ),
                  ),
                  SizedBox(width: 20),
                  SizedBox(
                    height: 50,
                    width: 100,
                    child: Column(mainAxisAlignment: .center,
                      crossAxisAlignment: .start,
                      children: [
                        Text('diaspaxson', style: TextStyle(fontWeight: .bold)),
                        Text(
                          'This is a Songdcwwecg',
                          maxLines: 1,
                          overflow: .ellipsis,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 10),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 2),
                    height: 30,
                    width: 80,
                    decoration: BoxDecoration(
                      border: Border.all(width: 2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text('Follow'),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
                width: 320,
                child: Text(
                  'This is a long Discription. aschchyvewhvehvwehvbhwebv',
                  maxLines: 1,
                  overflow: .ellipsis,
                ),
              ),
              SizedBox(height: 25),
            ],
          ),
        ),
        Positioned(
          right: 16.0,
          bottom: 16.0,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(CupertinoIcons.heart,size: 28.0),
              SizedBox(height: 18.0),

              Icon(CupertinoIcons.bubble_left,size: 28.0),
              SizedBox(height: 18.0),

              Icon(CupertinoIcons.paperplane, size: 28.0),
              SizedBox(height: 24.0),
              Icon(Icons.bookmark_border_outlined,size: 28.0),
              SizedBox(height: 24.0),
              Icon(Icons.menu),
              SizedBox(height: 24.0),
              Container(
                height: 20,
                width: 20,
                decoration: BoxDecoration(
                  color: Colors.blue,
                  border: Border.all(color: Colors.white),
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              SizedBox(height: 30),
            ],
          ),
        ),
      ],
    );
  }
}
