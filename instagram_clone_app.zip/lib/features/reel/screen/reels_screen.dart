import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:instagram_app/features/reel/widget/reel_component.dart';

class ReelsScreen extends StatelessWidget {
  const ReelsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reels'),
        leading: IconButton(
          onPressed: () => context.go('/'),
          icon: Icon(Icons.arrow_back),
        ),
      ),
      body: PageView.builder(
        scrollDirection: .vertical,
        itemCount: 10,
        itemBuilder: (context, index) => ReelComponent(),
      ),
      // CustomScrollView(
      //   slivers: [
      //      SliverAppBar(
      //       title: Text('Reels'),
      //       floating: false,
      //       pinned: false,
      //       snap: false,
      //     ),
      //     SliverList(
      //       delegate: SliverChildBuilderDelegate(
      //         (context, index) => ReelComponent(),
      //         childCount: 10,
      //       ),
      //     ),
      //   ],
      // ),
    );
  }
}
