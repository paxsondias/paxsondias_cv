import 'package:dio/dio.dart';
import 'package:instagram_app/models/post_model.dart';

class ApiService {
  final Dio _dio = Dio();

  Future<List<Posts>> fatchPosts() async {
    try {
      final response = await _dio.get('https://dummyjson.com/posts');
      if (response.statusCode == 200) {
        final post = response.data['posts'] as List;
        return post.map<Posts>((postJson) => Posts.fromJson(postJson)).toList();
      }
      throw Exception('Failed to fetch Posts: ${response.statusCode}');
    } catch (e) {
      rethrow;
    }
  }
}
