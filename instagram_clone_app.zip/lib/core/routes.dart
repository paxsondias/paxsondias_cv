import 'package:go_router/go_router.dart';
import 'package:instagram_app/features/homepage/screens/post_screen.dart';
import 'package:instagram_app/features/login/screen/login_screen.dart';
import 'package:instagram_app/features/profile.dart/screen/profile_screen.dart';
import 'package:instagram_app/features/reel/screen/reels_screen.dart';
import 'package:instagram_app/features/search/screen/search_screen.dart';
import 'package:instagram_app/features/settings/screens/settings_screens.dart';

final router = GoRouter(
  initialLocation: '/login_screen',
  routes: [
    GoRoute(path: '/', builder: (context, state) => PostScreen()),
    GoRoute(path: '/reels_screen', builder: (context, state) => ReelsScreen()),
    GoRoute(
      path: '/search_screen',
      builder: (context, state) => SearchScreen(),
    ),
    GoRoute(
      path: '/profile_screen',
      builder: (context, state) => ProfileScreen(),
    ),
    GoRoute(
      path: '/settings_screens',
      name: 'Settings',
      builder: (context, state) => SettingsScreens(),
    ),
    GoRoute(
      path: '/login_screen',
      builder: (context, state) => LoginScreen(),
    ),
  ],
);
