import os
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import Chroma

def run_ingestion_pipeline(file_path, db_directory):
    # --- STEP 1: Load the Text File ---
    print(f"🔄 Loading document from: {file_path}...")
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Could not find the file at {file_path}. Please check the path.")
        
    loader = TextLoader(file_path, encoding='utf-8')
    documents = loader.load()
    
    # --- STEP 2: Separate Text into Chunks ---
    print("✂️ Splitting text into chunks...")
    # chunk_size=300 means each chunk is roughly 800 characters long.
    # chunk_overlap=100 ensures the last 100 characters of a chunk are repeated 
    # in the next chunk so sentences/context don't get awkwardly cut in half.
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=300, 
        chunk_overlap=100,
        length_function=len
    )
    chunks = text_splitter.split_documents(documents)
    print(f"✅ Created {len(chunks)} text chunks.")

    # --- STEP 3: Import the Local Embedding Model ---
    print("🧠 Initializing Ollama Embedding Model (nomic-embed-text)...")
    embeddings = OllamaEmbeddings(model="nomic-embed-text")

    # --- STEP 4: Convert to Vectors and Save Locally ---
    print(f"💾 Vectorizing and saving to local database at '{db_directory}'...")
    # This takes the text chunks, passes them to Ollama to create vectors, 
    # and saves the resulting database directly into your folder.
    vector_db = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=db_directory
    )
    
    print("🎉 Success! Your local vector database is built and ready for RAG.")
    return vector_db

if __name__ == "__main__":
    # Define your inputs (Make sure 'tata_company_info.txt' is in the same directory)
    TEXT_FILE = "tata_company_info.txt" 
    VECTOR_DB_DIR = "./chroma_db"       # The folder where your vector files will be stored
    
    # Run the pipeline
    run_ingestion_pipeline(TEXT_FILE, VECTOR_DB_DIR)