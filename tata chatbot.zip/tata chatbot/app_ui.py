import streamlit as st
import os
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.llms import Ollama
from langchain_core.prompts import ChatPromptTemplate
from langchain_classic.chains import create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain

# --- 1. Page Configuration ---
st.set_page_config(page_title="Tata Group AI Assistant", page_icon="🏢", layout="centered")
st.title("🏢 Tata Group Local RAG Assistant")
st.caption("A fully local, private AI system querying your Tata Group knowledge base.")

# --- 2. Initialize RAG Chain (Cached so it only loads once) ---
@st.cache_resource
def load_rag_system():
    db_directory = "./chroma_db"
    if not os.path.exists(db_directory):
        st.error(f"❌ Database folder '{db_directory}' not found. Please run your ingestion pipeline first!")
        st.stop()
        
    embeddings = OllamaEmbeddings(model="nomic-embed-text")
    vector_db = Chroma(persist_directory=db_directory, embedding_function=embeddings)
    retriever = vector_db.as_retriever(search_kwargs={"k": 3})
    
    # Using a slightly higher temperature (0.2) for a more natural chat feel
    llm = Ollama(model="llama3.2", temperature=0.2)
    
    system_prompt = (
        "You are a helpful assistant specialized in Tata Group information.\n"
        "Use the following pieces of retrieved context to answer the question. "
        "If you don't know the answer, say that you don't know. Do not make things up.\n\n"
        "Context:\n{context}"
    )
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("human", "{input}"),
    ])
    
    question_answer_chain = create_stuff_documents_chain(llm, prompt)
    return create_retrieval_chain(retriever, question_answer_chain)

# Load the system into memory
try:
    rag_chain = load_rag_system()
except Exception as e:
    st.error(f"Failed to initialize RAG system: {e}")
    st.stop()

# --- 3. Initialize Chat History ---
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! Ask me anything about the Tata Group based on your uploaded documentation."}
    ]

# --- 4. Display Chat Messages ---
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- 5. Handle User Input ---
if user_query := st.chat_input("Ask something about Tata Group..."):
    # Display user message in chat message container
    with st.chat_message("user"):
        st.markdown(user_query)
    
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": user_query})
    
    # Generate response using RAG system
    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        with st.spinner("Searching local database and thinking..."):
            try:
                response = rag_chain.invoke({"input": user_query})
                answer = response["answer"]
                
                # Render the answer in the UI
                response_placeholder.markdown(answer)
                
                # Add assistant response to chat history
                st.session_state.messages.append({"role": "assistant", "content": answer})
                
            except Exception as e:
                error_msg = f"⚠️ An error occurred while generating the answer: {e}"
                response_placeholder.markdown(error_msg)
                st.session_state.messages.append({"role": "assistant", "content": error_msg})