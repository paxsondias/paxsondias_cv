import os
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.llms import Ollama
from langchain_core.prompts import ChatPromptTemplate

# 🛑 FIX: Notice the imports now come directly from langchain_classic
from langchain_classic.chains import create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain

def setup_rag_system(db_directory):
    print("🧠 Loading local embedding model...")
    embeddings = OllamaEmbeddings(model="nomic-embed-text")
    
    print("📂 Connecting to local vector database...")
    if not os.path.exists(db_directory):
        raise FileNotFoundError(f"Database folder '{db_directory}' not found. Run your ingestion pipeline first!")
        
    vector_db = Chroma(
        persist_directory=db_directory, 
        embedding_function=embeddings
    )
    
    # Configure retriever to fetch top 3 closest chunks
    retriever = vector_db.as_retriever(search_kwargs={"k": 3})
    
    print("🤖 Initializing local LLM (llama3.2)...")
    llm = Ollama(model="llama3.2", temperature=0.1)
    
    # Define a clean system prompt
    system_prompt = (
        "You are a helpful assistant specialized in Tata Group information.\n"
        "Use the following pieces of retrieved context to answer the question. "
        "If you don't know the answer, say that you don't know. Do not make things up.\n\n"
        "Context:\n{context}"
    )
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("human", "{input}"),
    ])
    
    print("⚙️ Creating RAG workflows...")
    # Link the LLM with the prompt template
    question_answer_chain = create_stuff_documents_chain(llm, prompt)
    # Link the retriever with the QA workflow
    rag_system = create_retrieval_chain(retriever, question_answer_chain)
    
    return rag_system

if __name__ == "__main__":
    VECTOR_DB_DIR = "./chroma_db"
    
    try:
        # Initialize the system
        rag_chain = setup_rag_system(VECTOR_DB_DIR)
        print("\n🚀 RAG System Online! Type 'exit' to close the program.\n")
        
        while True:
            query = input("❓ Ask something about Tata Group: ")
            if query.lower() == 'exit':
                print("Goodbye!")
                break
                
            if not query.strip():
                continue
                
            print("\n🔍 Querying local database & generating answer...")
            # LangChain v1 expects {"input": query} instead of {"query": query}
            response = rag_chain.invoke({"input": query})
            
            print("\n🤖 Answer:")
            print(response["answer"])
            print("-" * 60 + "\n")
            
    except Exception as e:
        print(f"\n❌ An error occurred: {e}")